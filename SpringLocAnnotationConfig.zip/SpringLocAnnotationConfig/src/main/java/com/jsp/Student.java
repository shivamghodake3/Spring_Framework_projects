package com.jsp;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Student {

	private String name;
	private int age;
	
	public String getName() {
		return name;
	}
	@Value(value="ram")
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	@Value(value="25")
	public void setAge(int age) {
		this.age = age;
	}
	
}
