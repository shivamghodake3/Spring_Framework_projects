package programs;

public class Sample {
	
	public void test() {
		System.out.println("Non static test method of sample class");
	}
}
