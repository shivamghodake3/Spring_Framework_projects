package com.jsp;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class StudentMain {

	public static void main(String[] args) {
		ApplicationContext ac=new AnnotationConfigApplicationContext(Config.class);
		Student s=(Student)ac.getBean("student");
		System.out.println("NAME: "+s.getName());
		System.out.println("AGE: "+s.getAge());
	}

}
