package com.jsp;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class CarEngineMain {

	public static void main(String[] args) {
		ApplicationContext ac=new AnnotationConfigApplicationContext(Config.class);
		Car c=(Car)ac.getBean("car");
		System.out.println("BRAND: "+c.brand);
		c.engine.testEngine();
	}

}
