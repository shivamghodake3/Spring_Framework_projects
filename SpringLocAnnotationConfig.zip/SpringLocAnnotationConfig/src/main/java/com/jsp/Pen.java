package com.jsp;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Pen {

	@Value(value="Reynolds")
	String brand;
	
	@Value(value="45")
	int price;
	
	@Value(value="black")
	String color;
}
