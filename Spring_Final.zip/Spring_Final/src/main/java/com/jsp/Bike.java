package com.jsp;

import org.springframework.stereotype.Component;

@Component
public class Bike implements Vehicle {
	
	@Override
	public void start() {
		System.out.println("it is a bike");
	}

}
