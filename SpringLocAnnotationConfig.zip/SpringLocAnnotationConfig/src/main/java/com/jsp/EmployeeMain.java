package com.jsp;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class EmployeeMain {

	public static void main(String[] args) {
		
		ApplicationContext ac=new AnnotationConfigApplicationContext(Config.class);
		Employee e=(Employee)ac.getBean("employee");
		System.out.println("Name: "+e.name);
		System.out.println("Salary: "+e.salary);
		System.out.println("Designation: "+e.designation);
	}

}
