package programs;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class PersonMain {

	public static void main(String[] args) {
		ApplicationContext ac=new ClassPathXmlApplicationContext("PersonAddressConfig.xml");
		Person p=(Person)ac.getBean("myperson");
		System.out.println("Name: "+p.name);
		System.out.println("AGE: "+p.age);
		System.out.println("ADDRESS: "+p.address.city);
		System.out.println(p.address.state);
		
	}

}
