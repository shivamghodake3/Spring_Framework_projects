package com.jsp;

import org.springframework.stereotype.Component;

@Component
public class Sample {

	public void test() {
		System.out.println("non static method of sample class is executing");
	}
}
