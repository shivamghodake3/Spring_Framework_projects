package com.jsp;

import org.springframework.stereotype.Component;

@Component
public class EmailService implements MessagingService {

	@Override
	public void sendMessage() {
		System.out.println("message is sent by email");
	}
}
