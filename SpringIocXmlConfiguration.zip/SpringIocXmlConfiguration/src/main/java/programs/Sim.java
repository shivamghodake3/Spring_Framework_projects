package programs;

public class Sim {

	public void testSim() {
		System.out.println("sim inserted successfully..!");
	}
}
