package programs;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class StudentMain {

	public static void main(String[] args) {
		ApplicationContext ac=new ClassPathXmlApplicationContext("MyConfig.xml");
		Student s=(Student)ac.getBean("mystudent"); //downcasting
		
		System.out.println(s.getName());
		System.out.println(s.getAge());
	}

}
