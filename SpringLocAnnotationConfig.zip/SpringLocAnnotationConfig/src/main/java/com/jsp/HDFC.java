package com.jsp;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
@Primary
public class HDFC implements ATM {
	
	@Override
	public void withdraw() {
		System.out.println("withdrawing amount from HDFC ATM");
	}

}
