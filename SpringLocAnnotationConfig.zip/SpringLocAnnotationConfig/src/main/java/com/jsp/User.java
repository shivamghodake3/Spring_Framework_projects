package com.jsp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class User {

	@Autowired
	Nokia nokia;
	
	@Autowired
	Samsung samsung;
	
	@Autowired
	@Qualifier(value="samsung") //informing IOC to inject samsung object into phone reference
	Mobile mobile;
	
}
