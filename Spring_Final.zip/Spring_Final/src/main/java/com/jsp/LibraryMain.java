package com.jsp;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class LibraryMain {

	public static void main(String[] args) {
		ApplicationContext ac=new AnnotationConfigApplicationContext(Config.class);
		Library l=(Library)ac.getBean("library");
		System.out.println("Libraray address: "+l.address);
		System.out.println("Book name: "+l.book.bookname);
		System.out.println("Book price: "+l.book.price);
	}

}
