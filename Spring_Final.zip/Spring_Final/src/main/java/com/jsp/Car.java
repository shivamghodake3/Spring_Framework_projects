package com.jsp;

import org.springframework.stereotype.Component;

@Component
public class Car implements Vehicle{
	@Override
	public void start() {
		System.out.println("it is a car");
	}
	
}
