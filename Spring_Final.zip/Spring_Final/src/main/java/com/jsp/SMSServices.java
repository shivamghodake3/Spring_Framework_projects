package com.jsp;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
@Primary
public class SMSServices implements MessagingService{

	@Override
	public void sendMessage() {
		System.out.println("message sent by the SMS");
	}
}
