package com.jsp;

import org.springframework.stereotype.Component;

@Component
public class Nokia implements Mobile {

	@Override
	public void calling(){
		System.out.println("calling from Nokia");
	}
}
