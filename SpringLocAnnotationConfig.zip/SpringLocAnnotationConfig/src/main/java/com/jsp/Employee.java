package com.jsp;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Employee {

	String name;
	double salary;
	String designation;
	
	Employee(@Value(value="Mala")String name, @Value(value="50000")double salary,@Value(value="manager")String designation){
		this.name=name;
		this.salary=salary;
		this.designation=designation;
	}
}
