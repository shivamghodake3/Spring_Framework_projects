package com.jsp;

public interface Vehicle {

	void start();
}
