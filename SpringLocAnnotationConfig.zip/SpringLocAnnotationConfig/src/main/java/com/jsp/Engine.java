package com.jsp;

import org.springframework.stereotype.Component;

@Component
public class Engine {

	public void testEngine() {
		System.out.println("Engine is Started");
	}
}
