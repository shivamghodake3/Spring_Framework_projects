package com.jsp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Car {

	String brand="BMW";
	
	@Autowired
	Engine engine;
	
//	@Autowired
//	public void setEngine(Engine engine) {
//		this.engine=engine;
//	}
//	
//	@Autowired
//	Car(Engine engine){
//		this.engine=engine;
//	}
	
}
