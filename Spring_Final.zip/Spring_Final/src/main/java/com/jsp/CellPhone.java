package com.jsp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class CellPhone {

	@Autowired
	SMSServices sms;
	
	@Autowired
	EmailService email;
	
	@Autowired
	MessagingService ms;
	
}
