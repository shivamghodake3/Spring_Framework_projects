package com.jsp;

public interface Animal {

	void sound();
}
