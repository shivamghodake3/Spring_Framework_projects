package com.jsp;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MessagingServicesMain {

	public static void main(String[] args) {
		ApplicationContext ac=new AnnotationConfigApplicationContext(Config.class);
		CellPhone c=(CellPhone)ac.getBean("cellPhone");
		c.sms.sendMessage();
		c.email.sendMessage();
		c.ms.sendMessage();
	}

}
