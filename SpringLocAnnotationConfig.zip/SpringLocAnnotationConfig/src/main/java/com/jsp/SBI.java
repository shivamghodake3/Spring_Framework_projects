package com.jsp;

import org.springframework.stereotype.Component;

@Component
public class SBI implements ATM {

	@Override
	public void withdraw() {
		System.out.println("withdrawing amount from SBI ATM");
	}
}
