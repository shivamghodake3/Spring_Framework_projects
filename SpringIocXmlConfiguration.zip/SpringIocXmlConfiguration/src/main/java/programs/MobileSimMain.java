package programs;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MobileSimMain {

	public static void main(String[] args) {
		ApplicationContext ac=new ClassPathXmlApplicationContext("MyConfig.xml");
		Mobile m=(Mobile)ac.getBean("mymobile");
		System.out.println(m.getBrand());
		System.out.println(m.getPrice());
		m.getSim().testSim();
	}

}
