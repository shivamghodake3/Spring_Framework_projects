package com.jsp;

public interface MessagingService {
	void sendMessage();
}
