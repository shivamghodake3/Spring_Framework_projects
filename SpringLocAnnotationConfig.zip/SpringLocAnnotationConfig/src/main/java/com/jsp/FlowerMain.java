package com.jsp;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class FlowerMain {

	public static void main(String[] args) {
		ApplicationContext ac=new AnnotationConfigApplicationContext(Config.class);
		Flower f1=(Flower)ac.getBean("flower");
		System.out.println("f1 address: "+f1);
		
		Flower f2=(Flower)ac.getBean("flower");
		System.out.println("f2 address: "+f2);
	}

}
