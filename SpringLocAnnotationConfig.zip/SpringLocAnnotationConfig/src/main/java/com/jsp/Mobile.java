package com.jsp;

public interface Mobile {

	void calling();
}
