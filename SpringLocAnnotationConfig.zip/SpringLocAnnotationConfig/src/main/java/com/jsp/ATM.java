package com.jsp;

public interface ATM {

	void withdraw();
}
