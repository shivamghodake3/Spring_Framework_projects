package com.jsp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class City {

	@Autowired
	SBI sbi;
	
	@Autowired
	HDFC hdfc;
	
	@Autowired
	ATM atm;
}
