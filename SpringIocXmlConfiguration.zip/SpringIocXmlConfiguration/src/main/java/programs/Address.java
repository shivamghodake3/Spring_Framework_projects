package programs;

public class Address {

	String state;
	String city;
	
	Address(String state,String city){
		this.city=city;
		this.state=state;
	}
}
