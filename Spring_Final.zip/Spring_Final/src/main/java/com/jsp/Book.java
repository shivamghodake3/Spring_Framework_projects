package com.jsp;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Book {

	@Value(value="java")
	String bookname;
	
	@Value(value="100")
	int price;
	
	
}
