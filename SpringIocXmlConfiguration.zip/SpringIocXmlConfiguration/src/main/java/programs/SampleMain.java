package programs;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SampleMain {

	public static void main(String[] args) {
		//creating IOC container-->application context
		ApplicationContext ac=new ClassPathXmlApplicationContext("MyConfig.xml");
		Sample s=(Sample)ac.getBean("mysample");//downcasting
		s.test();
	}

}
