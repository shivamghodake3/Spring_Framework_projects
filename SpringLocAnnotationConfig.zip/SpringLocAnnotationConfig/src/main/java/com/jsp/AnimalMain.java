package com.jsp;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class AnimalMain {

	public static void main(String[] args) {
		
		ApplicationContext ac=new AnnotationConfigApplicationContext(Config.class);
		Person p=(Person)ac.getBean("person");
		System.out.println("Name: "+p.name);
		p.dog.sound();
		p.animal.sound();
	}

}
